package mini_project;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class selenium_script {
	
	public static void main(String agrs[]) throws InterruptedException{
		
		WebDriver driver=new EdgeDriver();
		
		driver.get("https://www.snapdeal.com/");
		driver.manage().window().maximize();
		
		WebElement text = driver.findElement(By.name("keyword"));
		text.sendKeys("Bluetooth headphone");
		
		WebElement button = driver.findElement(By.className("searchTextSpan"));
		button.click();
		
		WebElement listbox = driver.findElement(By.xpath("//*[@id=\"content_wrapper\"]/div[7]/div[5]/div[3]/div[1]/div/div[2]/div/i"));
		listbox.click();
		
		WebElement lbox = driver.findElement(By.xpath("//*[@id=\"content_wrapper\"]/div[7]/div[5]/div[3]/div[1]/div/div[2]/ul/li[2]"));
		lbox.click();
		
		WebElement range1 = driver.findElement(By.xpath("(//input[@name='fromVal'])[1]"));
		range1.clear();
		range1.sendKeys("700");
		
		WebElement range2 = driver.findElement(By.xpath("(//input[@name='toVal'])[1]"));
		range2.clear();
		range2.sendKeys("1400");
		
		WebElement go = driver.findElement(By.cssSelector(".price-go-arrow"));
		go.click();
		
		Thread.sleep(3000);
		
		List<WebElement> products = driver.findElements(By.className("product-title"));
		
        List<WebElement> prices = driver.findElements(By.xpath("//*[@display-price]"));
        
        for (int i = 0; i < 5; i++) 
        {
            System.out.println("Product Name : " + products.get(i).getText());
            System.out.println("Product Price : " + prices.get(i).getText());
        }

          driver.quit();
      }
}

